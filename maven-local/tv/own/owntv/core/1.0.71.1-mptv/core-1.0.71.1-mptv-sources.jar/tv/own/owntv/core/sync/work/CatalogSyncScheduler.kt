package tv.own.owntv.core.sync.work

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.workDataOf
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onStart
import tv.own.owntv.core.sync.SyncContentTypes

class CatalogSyncScheduler(private val context: Context) {

    fun enqueueSync(
        sourceId: Long,
        reason: String = "manual",
        contentTypes: SyncContentTypes = SyncContentTypes(),
        baseItemCount: Int = 0,
        completesInitialSync: Boolean = false,
        /**
         * User asked for a clean resync: bypasses the catalog-shrink prune guard for this run only,
         * so titles the provider no longer lists are removed. Never set for an automatic sync.
         */
        forcePrune: Boolean = false,
        policy: ExistingWorkPolicy = ExistingWorkPolicy.REPLACE,
    ) {
        val request = OneTimeWorkRequestBuilder<CatalogSyncWorker>()
            .setInputData(workDataOf(
                CatalogSyncWorker.KEY_SOURCE_ID to sourceId,
                CatalogSyncWorker.KEY_REASON to reason,
                CatalogSyncWorker.KEY_BASE_ITEM_COUNT to baseItemCount,
                CatalogSyncWorker.KEY_LIVE to contentTypes.live,
                CatalogSyncWorker.KEY_MOVIES to contentTypes.movies,
                CatalogSyncWorker.KEY_SERIES to contentTypes.series,
                CatalogSyncWorker.KEY_COMPLETES_INITIAL_SYNC to completesInitialSync,
                CatalogSyncWorker.KEY_FORCE_PRUNE to forcePrune,
            ))
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build()
            )
            .addTag(TAG_CATALOG_SYNC)
            .addTag("source-$sourceId")
            .build()

        WorkManager.getInstance(context)
            .enqueueUniqueWork(workName(sourceId), policy, request)
    }

    fun cancelSync(sourceId: Long) {
        WorkManager.getInstance(context).cancelUniqueWork(workName(sourceId))
    }

    fun enqueueContentIndexBuild(reason: String = "fresh_sync") {
        val request = OneTimeWorkRequestBuilder<ContentIndexWorker>()
            .setInputData(workDataOf(ContentIndexWorker.KEY_REASON to reason))
            .addTag(ContentIndexWorker.TAG)
            .build()

        WorkManager.getInstance(context)
            .enqueueUniqueWork(ContentIndexWorker.workName(), ExistingWorkPolicy.KEEP, request)
    }

    fun enqueueTrendingRefresh(sourceId: Long, force: Boolean = false) {
        val request = OneTimeWorkRequestBuilder<TrendingRefreshWorker>()
            .setInputData(
                workDataOf(
                    TrendingRefreshWorker.KEY_SOURCE_ID to sourceId,
                    TrendingRefreshWorker.KEY_FORCE to force,
                ),
            )
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build(),
            )
            .addTag(TrendingRefreshWorker.WORK_TAG)
            .addTag("trending-source-$sourceId")
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            TrendingRefreshWorker.workName(sourceId),
            ExistingWorkPolicy.REPLACE,
            request,
        )
    }

    /**
     * Measure this provider's stream limit in the background.
     *
     * KEEP, not REPLACE: the measurement runs at most once per playlist, and a second enqueue from a
     * re-sync must not restart one that is already waiting for the user to stop watching.
     */
    fun enqueueConnectionMeasurement(sourceId: Long) {
        val request = OneTimeWorkRequestBuilder<ConnectionMeasurementWorker>()
            .setInputData(workDataOf(ConnectionMeasurementWorker.KEY_SOURCE_ID to sourceId))
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build(),
            )
            .addTag(ConnectionMeasurementWorker.WORK_TAG)
            .addTag("measure-source-$sourceId")
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            ConnectionMeasurementWorker.workName(sourceId),
            ExistingWorkPolicy.KEEP,
            request,
        )
        android.util.Log.i("ConnectionMeasurement", "measurement enqueued sourceId=$sourceId")
    }

    /**
     * Finish a Stalker catalogue in the background — start its drain now.
     *
     * A pass already running is left alone: it has a live position in a category and re-reads the
     * category priority between categories, so replacing it would only throw that position away. A
     * pass waiting out its retry delay is replaced by one that starts now — leaving it (KEEP) would
     * make the user's opened category, or a sync that just finished, wait up to that delay.
     *
     * [initialDelayMinutes] and [onlyIfWaiting] are for the resume after playback: start soon, and only
     * when a pass is actually waiting, so a playlist with nothing left to fill never gets a worker.
     *
     * Deliberately no battery/idle constraint beyond a network: a TV is mains-powered, and the point
     * is for the catalogue to be whole by the time the user scrolls that far, not overnight.
     */
    suspend fun enqueueCatalogBackfill(
        sourceId: Long,
        initialDelayMinutes: Long = 0,
        onlyIfWaiting: Boolean = false,
    ) {
        val infos = WorkManager.getInstance(context)
            .getWorkInfosForUniqueWorkFlow(CatalogBackfillWorker.workName(sourceId))
            .first()
        if (infos.any { it.state == WorkInfo.State.RUNNING }) return
        if (onlyIfWaiting && infos.none { !it.state.isFinished }) return
        submitBackfill(sourceId, initialDelayMinutes, ExistingWorkPolicy.REPLACE)
    }

    /**
     * The worker's own "come back later". Not [enqueueCatalogBackfill]: the calling pass is still
     * running under the same unique name, so anything but an append would either be dropped (KEEP)
     * or cancel the caller (REPLACE). APPEND_OR_REPLACE queues the next pass behind the one ending.
     */
    internal fun enqueueNextBackfillPass(sourceId: Long, delayMinutes: Long) =
        submitBackfill(sourceId, delayMinutes, ExistingWorkPolicy.APPEND_OR_REPLACE)

    private fun submitBackfill(sourceId: Long, initialDelayMinutes: Long, policy: ExistingWorkPolicy) {
        val request = OneTimeWorkRequestBuilder<CatalogBackfillWorker>()
            .setInputData(workDataOf(CatalogBackfillWorker.KEY_SOURCE_ID to sourceId))
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build(),
            )
            .apply {
                if (initialDelayMinutes > 0) {
                    setInitialDelay(initialDelayMinutes, java.util.concurrent.TimeUnit.MINUTES)
                }
            }
            .addTag(CatalogBackfillWorker.WORK_TAG)
            .addTag("backfill-source-$sourceId")
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            CatalogBackfillWorker.workName(sourceId),
            policy,
            request,
        )
        android.util.Log.i(
            "CatalogBackfillWorker",
            "backfill enqueued sourceId=$sourceId delayMinutes=$initialDelayMinutes policy=$policy",
        )
    }

    fun observeSync(sourceId: Long): Flow<CatalogSyncState> =
        WorkManager.getInstance(context)
            .getWorkInfosForUniqueWorkFlow(workName(sourceId))
            .map { infos ->
                val active = infos.firstOrNull { !it.state.isFinished }
                if (active == null) {
                    CatalogSyncState.Idle
                } else {
                    CatalogSyncState.Syncing(
                        baseItemCount = active.progress.getInt(CatalogSyncWorker.KEY_BASE_ITEM_COUNT, 0),
                        liveProcessed = active.progress.getInt(CatalogSyncWorker.KEY_PROGRESS_LIVE_PROCESSED, 0),
                        moviesProcessed = active.progress.getInt(CatalogSyncWorker.KEY_PROGRESS_MOVIES_PROCESSED, 0),
                        seriesProcessed = active.progress.getInt(CatalogSyncWorker.KEY_PROGRESS_SERIES_PROCESSED, 0),
                        liveActive = active.progress.getBoolean(CatalogSyncWorker.KEY_PROGRESS_LIVE_ACTIVE, false),
                        moviesActive = active.progress.getBoolean(CatalogSyncWorker.KEY_PROGRESS_MOVIES_ACTIVE, false),
                        seriesActive = active.progress.getBoolean(CatalogSyncWorker.KEY_PROGRESS_SERIES_ACTIVE, false),
                    )
                }
            }
            .distinctUntilChanged()

    /**
     * Emits at once, and again each time the playlist's catalogue work goes quiet — the moments its
     * stored counts may have changed. The background backfill counts as catalogue work: it keeps
     * adding titles for many minutes after the sync itself has finished, and a Playlists row that
     * re-counted only after the sync went on showing the few per cent stored by setup.
     *
     * Only a *running* pass is busy. Between passes the next one is already queued behind its retry
     * delay, and counting that as busy would hold the re-count until the whole catalogue is done.
     */
    fun catalogueSettled(sourceId: Long): Flow<Unit> {
        val syncing = observeSync(sourceId).map { it.isActive }.onStart { emit(false) }
        val backfilling = WorkManager.getInstance(context)
            .getWorkInfosForUniqueWorkFlow(CatalogBackfillWorker.workName(sourceId))
            .map { infos -> infos.any { it.state == WorkInfo.State.RUNNING } }
            .onStart { emit(false) }
        return combine(syncing, backfilling) { a, b -> a || b }
            .distinctUntilChanged()
            .filter { busy -> !busy }
            .map { }
    }

    companion object {
        const val TAG_CATALOG_SYNC = "catalog-sync"
        fun workName(sourceId: Long) = "catalog-sync-source-$sourceId"
    }
}

sealed interface CatalogSyncState {
    data object Idle : CatalogSyncState
    data class Syncing(
        val baseItemCount: Int,
        val liveProcessed: Int,
        val moviesProcessed: Int,
        val seriesProcessed: Int,
        val liveActive: Boolean,
        val moviesActive: Boolean,
        val seriesActive: Boolean,
    ) : CatalogSyncState {
        val totalProcessed: Int
            get() = liveProcessed + moviesProcessed + seriesProcessed
    }

    val isActive: Boolean
        get() = this is Syncing
}
