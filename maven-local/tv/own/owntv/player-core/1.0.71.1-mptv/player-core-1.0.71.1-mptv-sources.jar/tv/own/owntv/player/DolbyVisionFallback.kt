package tv.own.owntv.player

/**
 * MPTV: Dolby Vision files the TV's Dolby Vision decoder refuses (typically profile 7 — UHD Blu-ray
 * rips in MKV) still carry a standard HEVC Main10 / HDR10 base layer, so they play as 4K HDR10 on the
 * plain HEVC decoder. Media3 already offers HEVC as the alternative decoder for profiles 7/8/9, but it
 * still writes the Dolby Vision *profile constant* into the MediaFormat it hands that HEVC decoder,
 * which vendor HEVC decoders reject with `configure failed with err 0xffffffea` (BAD_VALUE). These
 * pure helpers decide when to prefer the HEVC base layer and what profile the HEVC decoder gets.
 */
object DolbyVisionFallback {
    const val MIME_DV = "video/dolby-vision"
    const val MIME_HEVC = "video/hevc"
    const val MIME_AVC = "video/avc"

    /** android.media.MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10 / HEVCProfileMain10HDR10. */
    const val HEVC_MAIN10 = 2
    const val HEVC_MAIN10_HDR10 = 0x1000

    /** Dolby Vision profile number from an RFC 6381 codecs string ("dvhe.07.06" → 7), or null. */
    fun profileOf(codecs: String?): Int? {
        if (codecs.isNullOrBlank()) return null
        val dv = codecs.split(',').map { it.trim() }
            .firstOrNull { it.startsWith("dvhe.") || it.startsWith("dvh1.") || it.startsWith("dvav.") || it.startsWith("dva1.") }
            ?: return null
        return dv.split('.').getOrNull(1)?.toIntOrNull()
    }

    /** Profile 7 = dual-layer Blu-ray Dolby Vision: device DV decoders on Android TVs rarely accept it,
     *  so the HDR10 base layer on the HEVC decoder goes first instead of last. */
    fun preferBaseLayer(sampleMime: String?, codecs: String?): Boolean =
        sampleMime == MIME_DV && profileOf(codecs) == 7

    /** True when a Dolby Vision track is being opened on a non-DV (HEVC/AVC base-layer) decoder, so the
     *  Dolby Vision profile Media3 put in the MediaFormat must be replaced. */
    fun needsProfileRewrite(sampleMime: String?, codecMime: String?): Boolean =
        sampleMime == MIME_DV && (codecMime == MIME_HEVC || codecMime == MIME_AVC)

    /** Profile the base-layer HEVC decoder is configured with (null = leave the key out). */
    fun baseLayerProfile(codecMime: String?, hdr: Boolean): Int? =
        if (codecMime == MIME_HEVC) (if (hdr) HEVC_MAIN10_HDR10 else HEVC_MAIN10) else null

    /** Reorders decoder MIME types so base-layer decoders come first; stable within each group. */
    fun <T> baseLayerFirst(decoders: List<T>, mimeOf: (T) -> String): List<T> =
        decoders.sortedBy { if (mimeOf(it) == MIME_DV) 1 else 0 }

    /** What a Dolby Vision *request* to the codec selector returns: the device's DV decoders, then its
     *  HEVC decoders as the base-layer route. Media3 itself only adds HEVC for profiles 4 and 8, never 7. */
    fun <T> withBaseLayer(dvDecoders: List<T>, hevcDecoders: List<T>, nameOf: (T) -> String): List<T> {
        val seen = HashSet<String>()
        return (dvDecoders + hevcDecoders).filter { seen.add(nameOf(it)) }
    }

    /** Final decoder order for one Dolby Vision track: no duplicates; profile 5 never goes to HEVC (it has no
     *  HDR10-compatible base layer, so it would show green/purple); profile 7 tries the HEVC base layer first. */
    fun <T> orderFor(codecs: String?, decoders: List<T>, mimeOf: (T) -> String, nameOf: (T) -> String): List<T> {
        val seen = HashSet<String>()
        val unique = decoders.filter { seen.add(nameOf(it)) }
        return when (profileOf(codecs)) {
            5 -> unique.filter { mimeOf(it) == MIME_DV }
            7 -> baseLayerFirst(unique, mimeOf)
            else -> unique
        }
    }
}
